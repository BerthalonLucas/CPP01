// public/app.js

document.addEventListener('DOMContentLoaded', () => {
    // Vérifier si nous sommes sur la page d'accueil ou la page de chat
    const isIndexPage = document.getElementById('userForm') !== null;
    const isChatPage = document.getElementById('chatForm') !== null;

    if (isIndexPage) {
        // Code pour la page d'accueil (index.html)
        const userForm = document.getElementById('userForm');
        userForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const nom = document.getElementById('nom').value;
            const prenom = document.getElementById('prenom').value;

            // Stocker les informations utilisateur dans localStorage
            localStorage.setItem('userInfo', JSON.stringify({ nom, prenom }));

            // Rediriger vers la page de chat
            window.location.href = 'chat.html';
        });
    } else if (isChatPage) {
        // Code pour la page de chat (chat.html)
        const userInfo = JSON.parse(localStorage.getItem('userInfo'));
        if (!userInfo) {
            // Rediriger vers la page d'accueil si les informations manquent
            window.location.href = 'index.html';
            return;
        }

        const welcomeMessage = document.getElementById('welcomeMessage');
        if (welcomeMessage) {
            welcomeMessage.innerText = `Bienvenue, ${userInfo.prenom} !`;
        }

        const chatWindow = document.getElementById('chatWindow');
        const chatForm = document.getElementById('chatForm');
        const messageInput = document.getElementById('messageInput');

        let conversationId = null;

        // Fonction pour charger les conversations
        async function loadConversations() {
            try {
                const response = await fetch(`/conversations?nom=${encodeURIComponent(userInfo.nom)}&prenom=${encodeURIComponent(userInfo.prenom)}`);
                const conversations = await response.json();

                const conversationList = document.getElementById('conversationList');
                if (conversationList) {
                    conversationList.innerHTML = '';

                    conversations.forEach(conv => {
                        const convElement = document.createElement('li');
                        convElement.classList.add('conversation-item');

                        const iconElement = document.createElement('i');
                        iconElement.classList.add('fas', 'fa-comments', 'icon');

                        const titleElement = document.createElement('span');
                        titleElement.classList.add('conversation-title');
                        titleElement.innerText = `Conversation du ${new Date(parseInt(conv._id)).toLocaleString()}`;

                        convElement.appendChild(iconElement);
                        convElement.appendChild(titleElement);

                        convElement.addEventListener('click', () => {
                            setActiveConversation(convElement);
                            loadConversation(conv._id);
                        });

                        conversationList.appendChild(convElement);
                    });
                }
            } catch (error) {
                console.error('Erreur lors du chargement des conversations:', error);
            }
        }

        // Fonction pour charger une conversation spécifique
        async function loadConversation(convId) {
            try {
                const response = await fetch(`/conversation/${convId}`);
                const data = await response.json();

                if (response.ok) {
                    conversationId = convId; // Mettre à jour l'ID de la conversation actuelle
                    displayConversation(data.conversation);
                } else {
                    console.error('Erreur lors du chargement de la conversation:', data.error);
                }
            } catch (error) {
                console.error('Erreur lors du chargement de la conversation:', error);
            }
        }

        // Fonction pour afficher une conversation dans la zone de chat
        function displayConversation(conversation) {
            if (chatWindow) {
                chatWindow.innerHTML = ''; // Vider la zone de chat

                conversation.messages.forEach(msg => {
                    appendMessage(
                        msg.sender === 'user' ? 'Utilisateur' : 'Chatbot',
                        msg.content,
                        msg.sender === 'user' ? 'user' : 'bot'
                    );
                });
            }
        }

        // Fonction pour marquer la conversation active (optionnel)
        function setActiveConversation(element) {
            // Retirer la classe 'active' de tous les éléments
            document.querySelectorAll('.conversation-item').forEach(item => {
                item.classList.remove('active');
            });
            // Ajouter la classe 'active' à l'élément cliqué
            element.classList.add('active');
        }

        // Gestionnaire de soumission du formulaire de chat
        if (chatForm) {
            chatForm.addEventListener('submit', async function (e) {
                e.preventDefault();
                const message = messageInput.value.trim();
                if (message === '') return;

                appendMessage('Utilisateur', message, 'user');
                messageInput.value = '';

                try {
                    showTypingIndicator();

                    const response = await fetch('/chat', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({ message, userInfo, conversationId }),
                    });

                    const data = await response.json();

                    hideTypingIndicator();

                    if (response.ok) {
                        appendMessage('Chatbot', data.reply, 'bot');

                        // Mettre à jour `conversationId` si nécessaire
                        if (!conversationId && data.conversationId) {
                            conversationId = data.conversationId;
                            loadConversations(); // Rafraîchir la liste des conversations
                        }
                    } else {
                        appendMessage('Erreur', data.error || 'Une erreur est survenue.', 'error');
                    }
                } catch (error) {
                    console.error(error);
                    hideTypingIndicator();
                    appendMessage('Erreur', 'Le serveur est inaccessible.', 'error');
                }
            });
        }

        // Fonctions utilitaires (appendMessage, showTypingIndicator, hideTypingIndicator, etc.)
        // ... (Assurez-vous d'inclure ces fonctions ici)

        // Charger les conversations au chargement de la page
        loadConversations();

        // Gestion du bouton "Nouvelle conversation"
        const newChatButton = document.getElementById('newChatButton');
        if (newChatButton) {
            newChatButton.addEventListener('click', function () {
                startNewConversation();
            });
        }

        function startNewConversation() {
            conversationId = null;
            if (chatWindow) {
                chatWindow.innerHTML = '';
            }
            document.querySelectorAll('.conversation-item').forEach(item => {
                item.classList.remove('active');
            });
            appendMessage('Système', 'Nouvelle conversation démarrée.', 'system');
        }

        // Gestion du bouton de bascule de la barre latérale
        const toggleSidebarButton = document.getElementById('toggleSidebar');
        if (toggleSidebarButton) {
            toggleSidebarButton.addEventListener('click', function () {
                toggleSidebar();
            });
        }

        function toggleSidebar() {
            const sidebar = document.querySelector('.sidebar');
            if (sidebar) {
                sidebar.classList.toggle('active');
            }
        }
    }
});
