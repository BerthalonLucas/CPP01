// public/js/chat.js

document.addEventListener('DOMContentLoaded', () => {
    const userInfo = JSON.parse(localStorage.getItem('userInfo'));
    if (!userInfo) {
        window.location.href = 'index.html';
    } else {
        const welcomeMessage = document.getElementById('welcomeMessage');
        if (welcomeMessage) {
            welcomeMessage.innerText = `Bienvenue, ${userInfo.prenom} !`;
        }
    }

    const chatWindow = document.getElementById('chatWindow');
    const chatForm = document.getElementById('chatForm');
    const messageInput = document.getElementById('messageInput');

    let conversationId = null;

    async function loadConversations() {
        try {
            const response = await fetch(`/conversations?nom=${encodeURIComponent(userInfo.nom)}&prenom=${encodeURIComponent(userInfo.prenom)}`);
            const conversations = await response.json();

            const conversationList = document.getElementById('conversationList');
            if (conversationList) {
                conversationList.innerHTML = '';

                conversations.forEach(conv => {
                    const convElement = document.createElement('li');
                    convElement.classList.add('conversation-item');

                    const iconElement = document.createElement('i');
                    iconElement.classList.add('fas', 'fa-comments', 'icon');

                    const titleElement = document.createElement('span');
                    titleElement.classList.add('conversation-title');
                    titleElement.innerText = `Conversation du ${new Date(parseInt(conv._id)).toLocaleString()}`;

                    convElement.appendChild(iconElement);
                    convElement.appendChild(titleElement);

                    convElement.addEventListener('click', () => {
                        setActiveConversation(convElement);
                        loadConversation(conv._id);
                    });

                    conversationList.appendChild(convElement);
                });
            }
        } catch (error) {
            console.error('Erreur lors du chargement des conversations:', error);
        }
    }

    async function loadConversation(convId) {
        try {
            const response = await fetch(`/conversation/${convId}`);
            const data = await response.json();

            if (response.ok) {
                conversationId = convId;
                displayConversation(data.conversation);
            } else {
                console.error('Erreur lors du chargement de la conversation:', data.error);
            }
        } catch (error) {
            console.error('Erreur lors du chargement de la conversation:', error);
        }
    }

    function displayConversation(conversation) {
        if (chatWindow) {
            chatWindow.innerHTML = '';

            conversation.messages.forEach(msg => {
                appendMessage(
                    msg.sender === 'user' ? 'Utilisateur' : 'Chatbot',
                    msg.content,
                    msg.sender === 'user' ? 'user' : 'bot'
                );
            });
        }
    }

    function setActiveConversation(element) {
        document.querySelectorAll('.conversation-item').forEach(item => {
            item.classList.remove('active');
        });
        element.classList.add('active');
    }

    if (chatForm) {
        chatForm.addEventListener('submit', async function (e) {
            e.preventDefault();
            const message = messageInput.value.trim();
            if (message === '') return;

            appendMessage('Utilisateur', message, 'user');
            messageInput.value = '';

            try {
                showTypingIndicator();

                const response = await fetch('/chat', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ message, userInfo, conversationId }),
                });

                const data = await response.json();

                hideTypingIndicator();

                if (response.ok) {
                    appendMessage('Chatbot', data.reply, 'bot');

                    if (!conversationId && data.conversationId) {
                        conversationId = data.conversationId;
                        loadConversations();
                    }
                } else {
                    appendMessage('Erreur', data.error || 'Une erreur est survenue.', 'error');
                }
            } catch (error) {
                console.error(error);
                hideTypingIndicator();
                appendMessage('Erreur', 'Le serveur est inaccessible.', 'error');
            }
        });
    }

    function appendMessage(sender, message, type) {
        if (!chatWindow) return;

        const messageElement = document.createElement('div');
        messageElement.classList.add('message', type);

        const bubbleElement = document.createElement('div');
        bubbleElement.classList.add('message-bubble', type);

        const icon = document.createElement('i');
        icon.classList.add('fas', type === 'user' ? 'fa-user' : 'fa-robot', 'icon');

        const messageHtml = marked.parse(message);

        const messageText = document.createElement('div');
        messageText.innerHTML = messageHtml;

        bubbleElement.appendChild(icon);
        bubbleElement.appendChild(messageText);

        messageElement.appendChild(bubbleElement);
        chatWindow.appendChild(messageElement);
        chatWindow.scrollTop = chatWindow.scrollHeight;

        messageText.querySelectorAll('pre code').forEach((block) => {
            hljs.highlightElement(block);
        });

        setTimeout(() => {
            bubbleElement.classList.add('show');
        }, 100);
    }

    function showTypingIndicator() {
        if (!chatWindow) return;

        const typingElement = document.createElement('div');
        typingElement.classList.add('message', 'bot', 'typing');

        const bubbleElement = document.createElement('div');
        bubbleElement.classList.add('message-bubble', 'bot', 'typing-indicator');

        for (let i = 0; i < 3; i++) {
            const dot = document.createElement('div');
            dot.classList.add('dot');
            bubbleElement.appendChild(dot);
        }

        typingElement.appendChild(bubbleElement);
        chatWindow.appendChild(typingElement);
        chatWindow.scrollTop = chatWindow.scrollHeight;

        setTimeout(() => {
            bubbleElement.classList.add('show');
        }, 100);
    }

    function hideTypingIndicator() {
        if (!chatWindow) return;

        const typingElements = chatWindow.getElementsByClassName('typing');
        while (typingElements[0]) {
            typingElements[0].parentNode.removeChild(typingElements[0]);
        }
    }

    const newChatButton = document.getElementById('newChatButton');

    if (newChatButton) {
        newChatButton.addEventListener('click', function () {
            startNewConversation();
        });
    }

    function startNewConversation() {
        conversationId = null;

        if (chatWindow) {
            chatWindow.innerHTML = '';
        }

        document.querySelectorAll('.conversation-item').forEach(item => {
            item.classList.remove('active');
        });

        appendMessage('Système', 'Nouvelle conversation démarrée.', 'system');
    }

    const toggleSidebarButton = document.getElementById('toggleSidebar');

    if (toggleSidebarButton) {
        toggleSidebarButton.addEventListener('click', function () {
            toggleSidebar();
        });
    }

    function toggleSidebar() {
        const sidebar = document.querySelector('.sidebar');
        if (sidebar) {
            sidebar.classList.toggle('active');
        }
    }

    loadConversations();
});
