// public/js/index.js

document.getElementById('userForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const nom = document.getElementById('nom').value;
    const prenom = document.getElementById('prenom').value;

    localStorage.setItem('userInfo', JSON.stringify({ nom, prenom }));

    window.location.href = 'chat.html';
});
