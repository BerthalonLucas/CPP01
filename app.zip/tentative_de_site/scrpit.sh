#!/bin/bash

# Nom des fichiers
input_file="texte_brut.txt"
output_file="metadata.txt"

# Vérification des fichiers
if [ ! -f "$input_file" ]; then
  echo "Fichier d'entrée '$input_file' introuvable !"
  exit 1
fi

# Création du fichier de sortie vide
> "$output_file"

# Lire tout le texte
text=$(cat "$input_file")

# Convertir en minuscules
text=$(echo "$text" | tr '[:upper:]' '[:lower:]')

# Supprimer les espaces multiples
text=$(echo "$text" | sed 's/  */ /g')

# Découper le texte en paragraphes (séparés par deux sauts de ligne)
IFS=$'\n\n' read -rd '' -a paragraphs <<<"$text"

# Regrouper les paragraphes pour former des segments plus grands
segment=""
max_chars=2500 # Ajustez cette valeur selon vos besoins
for para in "${paragraphs[@]}"; do
    if [ ${#segment} -lt $max_chars ]; then
        segment="$segment\n\n$para"
    else
        echo -e "$segment" >> "$output_file"
        segment="$para"
    fi
done

# Ajouter le dernier segment
if [ -n "$segment" ]; then
    echo -e "$segment" >> "$output_file"
fi

echo "Texte formaté en segments de taille maximale $max_chars caractères et sauvegardé dans '$output_file'."
