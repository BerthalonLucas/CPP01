// routes/chatRoutes.js

const express = require('express');
const chatController = require('../controllers/chatController');
const { loadSystemMessage, watchSystemMessageFile } = require('../utils/systemMessage');

module.exports = function() {
    const router = express.Router();

    loadSystemMessage();
    watchSystemMessageFile();

    router.post('/update-system-message', express.json(), chatController.updateSystemMessage);
    router.post('/chat', express.json(), chatController.handleChat); // Ajout de express.json() si nécessaire
    router.get('/conversations', chatController.getConversations);
    router.get('/conversation/:id', chatController.getConversationById);

    return router;
};
