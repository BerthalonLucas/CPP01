// app.js

const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const { generateEmbeddings } = require('./utils/generateEmbeddings');

const app = express();
const PORT = 8000;

app.use(express.json({ limit: '50mb' }));
app.use(cors());
app.use(express.static('public'));

const chatRoutes = require('./routes/chatRoutes')();
app.use('/', chatRoutes);

// Générer les embeddings avant de démarrer le serveur
generateEmbeddings().then(() => {
    console.log('Embeddings générés avec succès.');
    app.listen(PORT, () => {
        console.log(`Serveur backend démarré sur le port ${PORT}`);
    });
}).catch(err => {
    console.error('Erreur lors de la génération initiale des embeddings :', err);
});

const METADATA_FILE_PATH = path.join(__dirname, 'metadata.txt');

fs.watch(METADATA_FILE_PATH, (eventType, filename) => {
    if (eventType === 'change') {
        console.log('Fichier de métadonnées modifié, régénération des embeddings.');
        generateEmbeddings().catch(err => {
            console.error('Erreur lors de la régénération des embeddings après modification du fichier :', err);
        });
    }
});
