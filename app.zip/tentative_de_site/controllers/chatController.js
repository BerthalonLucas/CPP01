// controllers/chatController.js

const axios = require('axios');
const { encode } = require('gpt-3-encoder');
const { dbInsert, dbFindOne, dbUpdate, dbFind } = require('../utils/dbHelpers');
const { getCachedSystemMessage } = require('../utils/systemMessage');
const { cosineSimilarity } = require('../utils/cosineSimilarity');
const { generateEmbeddings, getCachedEmbeddings, getCachedMetadataSegments } = require('../utils/generateEmbeddings');
const fs = require('fs');
const path = require('path');

const EMBEDDING_API_URL = 'http://10.0.32.4:8080/v1/embeddings';
const LMSTUDIO_API_URL = 'http://10.0.32.4:8080/v1/chat/completions';

exports.updateSystemMessage = (req, res) => {
    // ... (code existant)
};

exports.handleChat = async (req, res) => {
    const { message, userInfo, conversationId } = req.body;
    try {
        // Générer les embeddings si ce n'est pas déjà fait
        await generateEmbeddings();

        const cachedEmbeddings = getCachedEmbeddings();
        const cachedMetadataSegments = getCachedMetadataSegments();

        // Calculer l'embedding du message utilisateur
        const userEmbeddingResponse = await axios.post(EMBEDDING_API_URL, {
            model: 'text-embedding-multilingual-e5-large-instruct',
            input: message
        });
        const userEmbedding = userEmbeddingResponse.data.data[0].embedding;

        // Calculer les similarités avec un seuil minimum
        const similarityThreshold = 0.25; // Ajustez ce seuil selon vos besoins
        const similarities = cachedEmbeddings.map((embedding, index) => {
            const similarity = cosineSimilarity(userEmbedding, embedding);
            return {
                index,
                similarity
            };
        }).filter(sim => sim.similarity >= similarityThreshold);

        // Trier les similarités décroissantes
        similarities.sort((a, b) => b.similarity - a.similarity);

        const MAX_TOKENS = 2048;
        let totalTokenCount = 0;

        let context = '';
        const systemMessageContent = getCachedSystemMessage();
        totalTokenCount += encode(systemMessageContent).length;
        totalTokenCount += encode(message).length;

        const contextSegments = [];
        let contextTokenCount = 0;

        for (const sim of similarities) {
            const segment = cachedMetadataSegments[sim.index];
            const segmentTokens = encode(segment).length;

            if (totalTokenCount + contextTokenCount + segmentTokens > MAX_TOKENS - 500) {
                break;
            }

            contextSegments.push(segment);
            contextTokenCount += segmentTokens;

            console.log(`Segment ajouté au contexte (${sim.index + 1}): Similarité ${sim.similarity.toFixed(4)}`);
        }

        context = contextSegments.join('\n\n');

        const updatedSystemMessageContent = contextSegments.length > 0
            ? `${systemMessageContent}\n\nVoici du contexte pour t'aider à répondre plus précisément à l'utilisateur. N'inclus pas ce contexte dans ta réponse, mais utilise-le pour fournir des réponses précises et utiles :\n\n${context}`
            : systemMessageContent;

        totalTokenCount += contextTokenCount;

        let convId = conversationId;
        let conversation;

        if (!convId) {
            convId = new Date().getTime().toString();
            conversation = {
                _id: convId,
                userInfo,
                messages: [],
            };
            await dbInsert(conversation);
            console.log(`Nouvelle conversation créée avec ID: ${convId}`);
        } else {
            conversation = await dbFindOne({ _id: convId });
            if (!conversation) {
                console.error('Conversation non trouvée pour ID:', convId);
                return res.status(500).json({ error: 'Erreur lors de la récupération de la conversation.' });
            }
        }

        // Recalculer les similarités à chaque message
        conversation.messages.push({ sender: 'user', content: message });

        const conversationHistory = conversation.messages.map(msg => ({
            role: msg.sender === 'user' ? 'user' : 'assistant',
            content: msg.content,
        }));

        const messages = [
            { role: 'system', content: updatedSystemMessageContent },
            ...conversationHistory,
        ];

        console.log('Total des tokens estimés :', totalTokenCount + contextTokenCount);
        console.log('Messages envoyés au modèle :', JSON.stringify(messages, null, 2));

        const responseLLM = await axios.post(LMSTUDIO_API_URL, {
            model: 'mixtral_7bx2_moe@q8_0',
            messages: messages,
        });

        const botReply = responseLLM.data.choices[0].message.content;

        conversation.messages.push({ sender: 'bot', content: botReply });

        await dbUpdate({ _id: convId }, conversation, {});

        res.json({ reply: botReply, conversationId: convId });

    } catch (error) {
        console.error('Erreur dans handleChat:', error);

        let errorMessage = "Une erreur est survenue.";
        if (error.response) {
            errorMessage += ` Code d'erreur : ${error.response.status}.`;
            errorMessage += ` Message : ${error.response.data.error || error.response.statusText}`;
        } else if (error.request) {
            errorMessage += " Aucune réponse reçue du serveur.";
        } else {
            errorMessage += ` ${error.message}`;
        }

        res.status(500).json({ error: errorMessage });
    }
};

exports.getConversations = async (req, res) => {
    const { nom, prenom } = req.query;

    try {
        console.log('Récupération des conversations pour :', nom, prenom);
        const docs = await dbFind({ 'userInfo.nom': nom, 'userInfo.prenom': prenom });
        res.json(docs);
    } catch (err) {
        console.error('Erreur lors de la récupération des conversations :', err);
        res.status(500).json({ error: 'Erreur lors de la récupération des conversations.' });
    }
};

exports.getConversationById = async (req, res) => {
    const convId = req.params.id;

    try {
        console.log('Récupération de la conversation avec ID :', convId);
        const doc = await dbFindOne({ _id: convId });
        if (!doc) {
            console.error('Conversation non trouvée pour ID :', convId);
            return res.status(404).json({ error: 'Conversation non trouvée.' });
        }
        res.json({ conversation: doc });
    } catch (err) {
        console.error('Erreur lors de la récupération de la conversation :', err);
        res.status(500).json({ error: 'Erreur lors de la récupération de la conversation.' });
    }
};
