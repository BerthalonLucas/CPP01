// utils/dbHelpers.js

const Datastore = require('nedb');

// Initialisation de la base de données
const db = {};
db.conversations = new Datastore({ filename: 'conversations.db', autoload: true });

// Fonctions d'assistance pour les opérations de la base de données
exports.dbInsert = (doc) => new Promise((resolve, reject) => {
    db.conversations.insert(doc, (err, newDoc) => {
        if (err) reject(err);
        else resolve(newDoc);
    });
});

exports.dbFindOne = (query) => new Promise((resolve, reject) => {
    db.conversations.findOne(query, (err, doc) => {
        if (err) reject(err);
        else resolve(doc);
    });
});

exports.dbUpdate = (query, update, options) => new Promise((resolve, reject) => {
    db.conversations.update(query, update, options, (err, numAffected) => {
        if (err) reject(err);
        else resolve(numAffected);
    });
});

exports.dbFind = (query) => new Promise((resolve, reject) => {
    db.conversations.find(query, (err, docs) => {
        if (err) reject(err);
        else resolve(docs);
    });
});
