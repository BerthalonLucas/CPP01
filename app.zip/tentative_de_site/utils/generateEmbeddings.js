// utils/generateEmbeddings.js

const fs = require('fs');
const path = require('path');
const axios = require('axios');

const EMBEDDING_API_URL = 'http://10.0.32.4:8080/v1/embeddings';
const METADATA_FILE_PATH = path.join(__dirname, '..', 'metadata.txt');

let cachedEmbeddings = [];
let cachedMetadataSegments = [];

async function generateEmbeddings() {
    try {
        const metadataContent = fs.readFileSync(METADATA_FILE_PATH, 'utf-8').trim();
        cachedMetadataSegments = metadataContent.split('\n\n');
        cachedEmbeddings = new Array(cachedMetadataSegments.length);

        console.log('Début de la génération des embeddings pour chaque séquence...');

        const concurrencyLimit = 20; // Ajustez ce nombre selon vos besoins
        let index = 0;

        async function worker() {
            while (true) {
                let currentIndex;
                // Synchronisation pour accéder à 'index'
                if (index < cachedMetadataSegments.length) {
                    currentIndex = index;
                    index++;
                } else {
                    break;
                }

                const segment = cachedMetadataSegments[currentIndex];
                try {
                    const response = await axios.post(EMBEDDING_API_URL, {
                        model: 'text-embedding-multilingual-e5-large-instruct',
                        input: segment
                    });
                    const embedding = response.data.data[0].embedding;
                    cachedEmbeddings[currentIndex] = embedding;
                    console.log(`Embedding pour la séquence ${currentIndex + 1}:`, embedding.slice(0, 3));
                } catch (error) {
                    console.error(`Erreur lors de la génération de l'embedding pour la séquence ${currentIndex + 1}:`, error.message);
                }
            }
        }

        const workers = [];
        for (let i = 0; i < concurrencyLimit; i++) {
            workers.push(worker());
        }

        await Promise.all(workers);

        console.log('Tous les embeddings ont été générés avec succès.');
    } catch (error) {
        console.error('Erreur lors de la génération des embeddings :', error.message);
        throw error;
    }
}

function getCachedEmbeddings() {
    return cachedEmbeddings;
}

function getCachedMetadataSegments() {
    return cachedMetadataSegments;
}

module.exports = {
    generateEmbeddings,
    getCachedEmbeddings,
    getCachedMetadataSegments
};
