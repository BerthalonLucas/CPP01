// utils/systemMessage.js

const fs = require('fs');
const path = require('path');

const SYSTEM_MESSAGE_FILE_PATH = path.join(__dirname, '..', 'system_message.txt');

let cachedSystemMessage = '';

// Fonction pour charger le message du système
function loadSystemMessage() {
    try {
        const message = fs.readFileSync(SYSTEM_MESSAGE_FILE_PATH, 'utf-8').trim();
        cachedSystemMessage = message;
        console.log('Message du système chargé avec succès.');
    } catch (error) {
        console.error('Erreur lors du chargement du message du système :', error);
        // Utiliser une valeur par défaut si le fichier n'est pas disponible
        cachedSystemMessage = "Tu es un assistant qui répondra au mieux aux questions de l'utilisateur.";
    }
}

// Fonction pour surveiller les changements dans le fichier de message du système
function watchSystemMessageFile() {
    fs.watch(SYSTEM_MESSAGE_FILE_PATH, (eventType, filename) => {
        if (eventType === 'change') {
            console.log('Fichier de message du système modifié, rechargement.');
            loadSystemMessage();
        }
    });
}

// Fonction pour obtenir le message du système mis en cache
function getCachedSystemMessage() {
    return cachedSystemMessage;
}

module.exports = {
    loadSystemMessage,
    watchSystemMessageFile,
    getCachedSystemMessage
};
