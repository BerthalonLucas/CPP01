#!/bin/bash

# Nom du fichier de sortie
OUTPUT_FILE="arborescence.txt"

# Vérifie si le fichier de sortie existe déjà, et le supprime pour éviter des doublons
if [ -f "$OUTPUT_FILE" ]; then
  rm "$OUTPUT_FILE"
fi

# Étape 1 : Générer l'arborescence en excluant "node_modules"
echo "--- Arborescence des dossiers ---" >> "$OUTPUT_FILE"
tree -I "node_modules" >> "$OUTPUT_FILE"

# Étape 2 : Lister tous les fichiers sauf ceux avec extension .png, .txt, package-lock.json, et ceux sous "node_modules"
echo -e "\n--- Liste des fichiers ---" >> "$OUTPUT_FILE"
find . -type f \
  ! -name "*.png" \
  ! -name "*.txt" \
  ! -name "package-lock.json" \
  -not -path "*/node_modules/*" >> "$OUTPUT_FILE"

# Étape 3 : Ajouter le contenu des fichiers restants
echo -e "\n--- Contenu des fichiers ---" >> "$OUTPUT_FILE"
find . -type f \
  ! -name "*.png" \
  ! -name "*.txt" \
  ! -name "*.db" \
  ! -name "package-lock.json" \
  -not -path "*/node_modules/*" | while IFS= read -r file; do
  echo -e "\n--- Contenu de $file ---" >> "$OUTPUT_FILE"
  cat "$file" >> "$OUTPUT_FILE" 2>/dev/null || echo "Impossible de lire le fichier : $file" >> "$OUTPUT_FILE"
done
